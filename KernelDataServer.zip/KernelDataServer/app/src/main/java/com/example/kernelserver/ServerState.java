package com.example.kernelserver;

public class ServerState {
    private static volatile boolean running = false;
    private static volatile int port = 0;
    private static volatile String error = null;

    public static void setRunning(boolean r, int p) { running = r; port = p; }
    public static boolean isRunning() { return running; }
    public static int getPort() { return port; }
    public static void setError(String e) { error = e; }
    public static String getError() { return error; }
}
