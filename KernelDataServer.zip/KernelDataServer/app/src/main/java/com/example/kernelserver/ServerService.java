package com.example.kernelserver;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;

public class ServerService extends Service {

    public static final String ACTION_START = "start";
    public static final String ACTION_STOP = "stop";
    public static final String EXTRA_PORT = "port";
    public static final String EXTRA_TOKEN = "token";
    private static final String CHANNEL = "kernel_server";

    private HttpServer server;

    @Override
    public void onCreate() {
        super.onCreate();
        createChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        String action = intent.getAction();
        if (ACTION_STOP.equals(action)) {
            stopServer();
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }
        int port = intent.getIntExtra(EXTRA_PORT, 8080);
        String token = intent.getStringExtra(EXTRA_TOKEN);
        startForeground(1, buildNotification("服务运行中，端口 " + port));
        stopServer();
        server = new HttpServer(this, port, token, msg -> { });
        try {
            server.start();
        } catch (Exception e) {
            ServerState.setError("启动失败: " + e.getMessage());
            stopSelf();
        }
        ServerState.setRunning(true, port);
        return START_STICKY;
    }

    private void stopServer() {
        if (server != null) { server.stop(); server = null; }
        ServerState.setRunning(false, 0);
    }

    @Override
    public void onDestroy() {
        stopServer();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "数据服务", NotificationManager.IMPORTANCE_LOW);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(ch);
        }
    }

    private Notification buildNotification(String text) {
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL)
                : new Notification.Builder(this);
        b.setContentTitle("Kernel Data Server")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.stat_sys_upload)
                .setOngoing(true);
        return b.build();
    }
}
