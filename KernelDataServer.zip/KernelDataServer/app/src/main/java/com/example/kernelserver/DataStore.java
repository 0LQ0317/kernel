package com.example.kernelserver;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** JSONL 存储：每行一条上报记录 */
public class DataStore {

    public static class Record {
        public long id;
        public String deviceId;
        public String kernelVersion;
        public String action;
        public long timestamp;
        public String raw;

        public JSONObject toJson() throws Exception {
            JSONObject o = new JSONObject();
            o.put("id", id);
            o.put("device_id", deviceId);
            o.put("kernel_version", kernelVersion);
            o.put("action", action);
            o.put("timestamp", timestamp);
            o.put("time", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date(timestamp)));
            o.put("data", raw == null ? new JSONObject() : new JSONObject(raw));
            return o;
        }
    }

    private static final String FILE_NAME = "records.jsonl";
    private static final Object LOCK = new Object();

    private static File file(Context c) {
        return new File(c.getFilesDir(), FILE_NAME);
    }

    public static Record save(Context c, JSONObject body) throws Exception {
        Record r = new Record();
        synchronized (LOCK) {
            long nextId = 1;
            for (Record x : loadAll(c)) if (x.id >= nextId) nextId = x.id + 1;
            r.id = nextId;
            r.deviceId = body.optString("device_id", body.optString("deviceId", "unknown"));
            r.kernelVersion = body.optString("kernel_version", body.optString("kernelVersion", "unknown"));
            r.action = body.optString("action", body.optString("event", "report"));
            r.timestamp = body.optLong("timestamp", System.currentTimeMillis());
            r.raw = body.toString();

            JSONObject line = new JSONObject();
            line.put("id", r.id);
            line.put("device_id", r.deviceId);
            line.put("kernel_version", r.kernelVersion);
            line.put("action", r.action);
            line.put("timestamp", r.timestamp);
            line.put("raw", r.raw);

            try (FileOutputStream fos = new FileOutputStream(file(c), true);
                 OutputStreamWriter w = new OutputStreamWriter(fos, StandardCharsets.UTF_8)) {
                w.write(line.toString());
                w.write("\n");
            }
        }
        return r;
    }

    public static List<Record> loadAll(Context c) {
        List<Record> list = new ArrayList<>();
        File f = file(c);
        if (!f.exists()) return list;
        synchronized (LOCK) {
            try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(f), StandardCharsets.UTF_8))) {
                String s;
                while ((s = br.readLine()) != null) {
                    if (s.trim().isEmpty()) continue;
                    try {
                        JSONObject o = new JSONObject(s);
                        Record r = new Record();
                        r.id = o.optLong("id");
                        r.deviceId = o.optString("device_id");
                        r.kernelVersion = o.optString("kernel_version");
                        r.action = o.optString("action");
                        r.timestamp = o.optLong("timestamp");
                        r.raw = o.optString("raw");
                        list.add(r);
                    } catch (Exception ignored) { }
                }
            } catch (Exception ignored) { }
        }
        return list;
    }

    public static JSONObject stats(Context c) throws Exception {
        List<Record> all = loadAll(c);
        Set<String> devices = new LinkedHashSet<>();
        java.util.Map<String, Integer> actions = new java.util.HashMap<>();
        for (Record r : all) {
            devices.add(r.deviceId);
            actions.put(r.action, actions.getOrDefault(r.action, 0) + 1);
        }
        JSONObject o = new JSONObject();
        o.put("total_records", all.size());
        o.put("total_devices", devices.size());
        JSONObject a = new JSONObject();
        for (java.util.Map.Entry<String, Integer> e : actions.entrySet()) a.put(e.getKey(), e.getValue());
        o.put("actions", a);
        return o;
    }

    public static JSONArray recent(Context c, int limit) throws Exception {
        List<Record> all = loadAll(c);
        JSONArray arr = new JSONArray();
        for (int i = all.size() - 1; i >= 0 && arr.length() < limit; i--) arr.put(all.get(i).toJson());
        return arr;
    }

    public static void clear(Context c) {
        synchronized (LOCK) {
            File f = file(c);
            if (f.exists()) f.delete();
        }
    }
}
