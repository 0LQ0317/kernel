package com.example.kernelserver;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.Collections;
import java.util.List;

public class MainActivity extends android.app.Activity {

    private EditText etPort, etToken;
    private TextView tvStatus, tvStats, tvRecords;
    private Button btnToggle, btnRefresh, btnClear;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private SharedPreferences sp;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("cfg", MODE_PRIVATE);

        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        root.setPadding(pad, pad, pad, pad);
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("Kernel Data Server");
        title.setTextSize(22);
        root.addView(title);

        TextView tip = new TextView(this);
        tip.setText("内核上报数据接收服务（HTTP）");
        tip.setPadding(0, pad / 4, 0, pad);
        root.addView(tip);

        etPort = new EditText(this);
        etPort.setHint("端口，例如 8080");
        etPort.setInputType(InputType.TYPE_CLASS_NUMBER);
        etPort.setText(sp.getString("port", "8080"));
        root.addView(etPort);

        etToken = new EditText(this);
        etToken.setHint("Token（可留空=不鉴权）");
        etToken.setText(sp.getString("token", ""));
        root.addView(etToken);

        btnToggle = new Button(this);
        btnToggle.setText("启动服务");
        root.addView(btnToggle);

        tvStatus = new TextView(this);
        tvStatus.setTextSize(15);
        tvStatus.setPadding(0, pad / 2, 0, pad / 2);
        root.addView(tvStatus);

        btnRefresh = new Button(this);
        btnRefresh.setText("刷新统计");
        root.addView(btnRefresh);

        tvStats = new TextView(this);
        tvStats.setTextSize(14);
        tvStats.setPadding(0, pad / 2, 0, pad / 2);
        root.addView(tvStats);

        TextView rTitle = new TextView(this);
        rTitle.setText("最近上报记录");
        rTitle.setTextSize(16);
        root.addView(rTitle);

        tvRecords = new TextView(this);
        tvRecords.setTextSize(12);
        tvRecords.setTextIsSelectable(true);
        root.addView(tvRecords);

        btnClear = new Button(this);
        btnClear.setText("清空所有数据");
        root.addView(btnClear);

        TextView usage = new TextView(this);
        usage.setTextSize(12);
        usage.setPadding(0, pad, 0, 0);
        usage.setText("上报示例：\n" +
                "curl -X POST http://<手机IP>:8080/api/upload \\n" +
                "  -H 'Content-Type: application/json' \\n" +
                "  -H 'X-API-Token: 你的token' \\n" +
                "  -d '{\"device_id\":\"dev1\",\"kernel_version\":\"1.0\",\"action\":\"boot\",\"data\":{\"cpu\":8}}'\n\n" +
                "GET /api/stats  统计\nGET /api/records  最近200条");
        root.addView(usage);

        setContentView(scroll);

        btnToggle.setOnClickListener(v -> toggle());
        btnRefresh.setOnClickListener(v -> refresh());
        btnClear.setOnClickListener(v -> confirmClear());

        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
        refresh();
    }

    private void toggle() {
        if (ServerState.isRunning()) {
            Intent i = new Intent(this, ServerService.class).setAction(ServerService.ACTION_STOP);
            startService(i);
            ui.postDelayed(this::refresh, 300);
            return;
        }
        String p = etPort.getText().toString().trim();
        int port;
        try { port = Integer.parseInt(p); } catch (Exception e) { toast("端口不合法"); return; }
        if (port < 1024 || port > 65535) { toast("请使用 1024-65535 之间的端口"); return; }
        String token = etToken.getText().toString().trim();
        sp.edit().putString("port", p).putString("token", token).apply();

        Intent i = new Intent(this, ServerService.class)
                .setAction(ServerService.ACTION_START)
                .putExtra(ServerService.EXTRA_PORT, port)
                .putExtra(ServerService.EXTRA_TOKEN, token);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        ui.postDelayed(this::refresh, 500);
    }

    private void refresh() {
        boolean running = ServerState.isRunning();
        btnToggle.setText(running ? "停止服务" : "启动服务");
        String err = ServerState.getError();
        if (running) {
            tvStatus.setText("状态：运行中，端口 " + ServerState.getPort() + "\n访问地址：\n" + addresses(ServerState.getPort()));
        } else {
            tvStatus.setText("状态：已停止" + (err == null ? "" : "\n错误：" + err));
        }
        new Thread(() -> {
            String statsText, recordsText;
            try {
                JSONObject st = DataStore.stats(MainActivity.this);
                StringBuilder sb = new StringBuilder();
                sb.append("总记录数：").append(st.optInt("total_records"))
                        .append("    设备数：").append(st.optInt("total_devices"))
                        .append("\n\n按行为统计：\n");
                JSONObject acts = st.optJSONObject("actions");
                if (acts != null) {
                    JSONArray names = acts.names();
                    if (names != null) {
                        for (int i = 0; i < names.length(); i++) {
                            String k = names.optString(i);
                            sb.append("  ").append(k).append(" : ").append(acts.optInt(k)).append("\n");
                        }
                    }
                }
                statsText = sb.toString();

                JSONArray arr = DataStore.recent(MainActivity.this, 50);
                StringBuilder rb = new StringBuilder();
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject o = arr.optJSONObject(i);
                    rb.append("#").append(o.optLong("id"))
                            .append("  ").append(o.optString("time"))
                            .append("\n  设备: ").append(o.optString("device_id"))
                            .append("\n  内核: ").append(o.optString("kernel_version"))
                            .append("\n  行为: ").append(o.optString("action"))
                            .append("\n  数据: ").append(o.optJSONObject("data"))
                            .append("\n\n");
                }
                recordsText = arr.length() == 0 ? "暂无数据" : rb.toString();
            } catch (Exception e) {
                statsText = "统计失败: " + e.getMessage();
                recordsText = "";
            }
            final String s1 = statsText, s2 = recordsText;
            ui.post(() -> { tvStats.setText(s1); tvRecords.setText(s2); });
        }).start();
    }

    private void confirmClear() {
        new AlertDialog.Builder(this)
                .setTitle("确认清空")
                .setMessage("将删除全部已接收的上报数据，且无法恢复。")
                .setPositiveButton("清空", (d, w) -> {
                    DataStore.clear(MainActivity.this);
                    toast("已清空");
                    refresh();
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private String addresses(int port) {
        StringBuilder sb = new StringBuilder();
        sb.append("  http://127.0.0.1:").append(port).append("/\n");
        try {
            List<NetworkInterface> nis = Collections.list(NetworkInterface.getNetworkInterfaces());
            for (NetworkInterface ni : nis) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                    if (a instanceof Inet4Address && !a.isLoopbackAddress()) {
                        sb.append("  http://").append(a.getHostAddress()).append(":").append(port).append("/\n");
                    }
                }
            }
        } catch (Exception ignored) { }
        return sb.toString();
    }

    private void toast(String m) { Toast.makeText(this, m, Toast.LENGTH_SHORT).show(); }

    @Override
    protected void onResume() { super.onResume(); refresh(); }
}
