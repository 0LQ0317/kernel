package com.example.kernelserver;

import android.content.Context;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class HttpServer {

    public interface Listener {
        void onServerMessage(String msg);
    }

    private static final String TAG = "KernelHttp";
    private final Context ctx;
    private final int port;
    private final String token;
    private final Listener listener;
    private volatile boolean running = false;
    private ServerSocket serverSocket;
    private ExecutorService pool;

    public HttpServer(Context ctx, int port, String token, Listener listener) {
        this.ctx = ctx.getApplicationContext();
        this.port = port;
        this.token = token;
        this.listener = listener;
    }

    public void start() throws Exception {
        serverSocket = new ServerSocket();
        serverSocket.setReuseAddress(true);
        serverSocket.bind(new InetSocketAddress(port));
        running = true;
        pool = Executors.newFixedThreadPool(8);
        Thread t = new Thread(() -> {
            while (running) {
                try {
                    Socket s = serverSocket.accept();
                    pool.execute(() -> handle(s));
                } catch (Exception e) {
                    if (running) Log.w(TAG, "accept: " + e.getMessage());
                }
            }
        }, "http-accept");
        t.start();
        log("服务已启动，端口 " + port);
    }

    public void stop() {
        running = false;
        try { if (serverSocket != null) serverSocket.close(); } catch (Exception ignored) { }
        if (pool != null) pool.shutdownNow();
        log("服务已停止");
    }

    private void log(String m) {
        if (listener != null) listener.onServerMessage(m);
    }

    private void handle(Socket socket) {
        try (Socket s = socket) {
            s.setSoTimeout(15000);
            InputStream in = s.getInputStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));

            String requestLine = br.readLine();
            if (requestLine == null) return;
            String[] parts = requestLine.split(" ");
            if (parts.length < 2) return;
            String method = parts[0];
            String path = parts[1];

            Map<String, String> headers = new HashMap<>();
            String line;
            while ((line = br.readLine()) != null && !line.isEmpty()) {
                int i = line.indexOf(':');
                if (i > 0) headers.put(line.substring(0, i).trim().toLowerCase(), line.substring(i + 1).trim());
            }

            int len = 0;
            try { len = Integer.parseInt(headers.getOrDefault("content-length", "0")); } catch (Exception ignored) { }
            StringBuilder body = new StringBuilder();
            if (len > 0) {
                char[] buf = new char[Math.min(len, 8192)];
                int remaining = len;
                while (remaining > 0) {
                    int r = br.read(buf, 0, Math.min(buf.length, remaining));
                    if (r < 0) break;
                    body.append(buf, 0, r);
                    remaining -= r;
                }
            }

            String pathOnly = path.contains("?") ? path.substring(0, path.indexOf('?')) : path;

            if (!authorized(headers, path)) {
                respond(s, 401, "{\"ok\":false,\"error\":\"unauthorized\"}", "application/json");
                return;
            }

            if ("POST".equalsIgnoreCase(method) && ("/api/upload".equals(pathOnly) || "/upload".equals(pathOnly))) {
                try {
                    JSONObject o = new JSONObject(body.toString());
                    DataStore.Record r = DataStore.save(ctx, o);
                    respond(s, 200, "{\"ok\":true,\"id\":" + r.id + "}", "application/json");
                } catch (Exception e) {
                    respond(s, 400, "{\"ok\":false,\"error\":" + JSONObject.quote(e.getMessage()) + "}", "application/json");
                }
            } else if ("GET".equalsIgnoreCase(method) && "/api/stats".equals(pathOnly)) {
                respond(s, 200, DataStore.stats(ctx).toString(), "application/json");
            } else if ("GET".equalsIgnoreCase(method) && "/api/records".equals(pathOnly)) {
                JSONArray arr = DataStore.recent(ctx, 200);
                JSONObject o = new JSONObject();
                o.put("ok", true);
                o.put("records", arr);
                respond(s, 200, o.toString(), "application/json");
            } else if ("GET".equalsIgnoreCase(method) && ("/".equals(pathOnly) || "/health".equals(pathOnly))) {
                respond(s, 200, "{\"ok\":true,\"service\":\"KernelDataServer\"}", "application/json");
            } else {
                respond(s, 404, "{\"ok\":false,\"error\":\"not found\"}", "application/json");
            }
        } catch (Exception e) {
            Log.w(TAG, "handle: " + e.getMessage());
        }
    }

    private boolean authorized(Map<String, String> headers, String path) {
        if (token == null || token.isEmpty()) return true;
        String h = headers.get("x-api-token");
        if (token.equals(h)) return true;
        String auth = headers.get("authorization");
        if (auth != null && auth.equals("Bearer " + token)) return true;
        return path.contains("token=" + token);
    }

    private void respond(Socket s, int code, String body, String type) {
        try {
            byte[] b = body.getBytes(StandardCharsets.UTF_8);
            String head = "HTTP/1.1 " + code + " " + (code == 200 ? "OK" : code == 401 ? "Unauthorized" : code == 404 ? "Not Found" : "Bad Request") + "\r\n"
                    + "Content-Type: " + type + "; charset=utf-8\r\n"
                    + "Content-Length: " + b.length + "\r\n"
                    + "Access-Control-Allow-Origin: *\r\n"
                    + "Connection: close\r\n\r\n";
            OutputStream out = s.getOutputStream();
            out.write(head.getBytes(StandardCharsets.UTF_8));
            out.write(b);
            out.flush();
        } catch (Exception ignored) { }
    }
}
